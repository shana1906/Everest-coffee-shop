# Everest Coffee Shop ☕

Welcome to the official website of Everest Coffee Shop! This is a cozy little place to enjoy fresh coffee, snacks, and more.

## 📂 Pages
- `index.html` – Home
- `menu.html` – Menu with prices in Rs.
- `about.html` – About our story
- `contact.html` – Find us at No. 10, Main Street, Jaffna

## 🎨 Theme
Light cream and mocha brown for a warm and cozy café feel.

## 🌐 How to Host
You can host this website on GitHub Pages by uploading these files to your GitHub repo and enabling GitHub Pages in the Settings.

Enjoy your digital café presence! ☕✨
